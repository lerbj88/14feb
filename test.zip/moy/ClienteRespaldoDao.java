package com.project.bdflujos.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.Map;

@Repository
@Transactional
public class ClienteRespaldoDao extends JdbcDaoSupport {

    @Autowired
    public ClienteRespaldoDao(DataSource dataSource2) {
        this.setDataSource(dataSource2);
    }

    @Transactional
    public void callInsertClientePrueba(Integer id, String name) {
        SimpleJdbcCall jdbcCall = new
                SimpleJdbcCall(getDataSource()).withProcedureName("insert_cliente_prueba");

        SqlParameterSource in = new MapSqlParameterSource().addValue("user_id", id)
                .addValue("user_name", name);
        Map<String, Object> out = jdbcCall.execute(in);

        System.out.println(out.toString());
    }

}
