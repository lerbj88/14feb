package com.project.bdflujos.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ClienteDaoTest {

    @Autowired
    ClienteDao clienteDao;

    @Autowired
    ClienteRespaldoDao clienteRespaldoDao;

    @Test
    public void callInsertClientePruebaTest() {
        clienteDao.callInsertClientePrueba(1447, "Moy2");
        System.out.println("Se ejecuto en BD 1!");
        clienteRespaldoDao.callInsertClientePrueba(1447, "Moy2");
        System.out.println("Se ejecuto en BD 2!");
    }
}