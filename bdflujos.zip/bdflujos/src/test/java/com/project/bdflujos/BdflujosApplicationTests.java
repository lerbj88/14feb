package com.project.bdflujos;

import com.project.bdflujos.dao.ClienteDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BdflujosApplicationTests {

    @Test
    public void contextLoads() {
    }

    @Autowired
    ClienteDao clienteDao;

    @Test
    public void insertclientetest(){
        clienteDao.insertclientes( "a", "b" );
    }

    @Test
    public void insertclientetest2(){
        clienteDao.callInsertClientePrueba( "a", "b" );
    }


}

