package com.project.bdflujos.controller;

import com.project.bdflujos.dao.ClienteDao;
import com.project.bdflujos.model.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

@Controller
@RequestMapping("/cliente")
public class ClienteController {

    @Autowired
    private ClienteDao clienteDao;


/*

    @RequestMapping(value = { "/list" }, method = RequestMethod.GET)
    public String clientes(Model model) throws SQLException {

        List<Cliente> list = clienteDao.findAll();
        model.addAttribute("cliente", list);

        return "cliente/list";
    }
*/
    @GetMapping("/form")
    public String form(ModelMap model){
        Cliente cliente = new Cliente();
        model.addAttribute("cliente", cliente);
        model.addAttribute("outMessage", "");
        return "cliente/form";
    }

     /*   @PostMapping("/form")
    public String agregar(@ModelAttribute(value = "cliente") Cliente cliente, BindingResult errors, SessionStatus status, ModelMap model) {
        if (errors.hasErrors()) {
            return "cliente/form";
        }


        status.setComplete();
        String outMessage = clienteDao.insertclientes(cliente.getId(), cliente.getName());
        //return "redirect:form";

        model.addAttribute("cliente", clientee);
        model.addAttribute("outMessage", outMessage);
        return "cliente/form";
    }

*/
}