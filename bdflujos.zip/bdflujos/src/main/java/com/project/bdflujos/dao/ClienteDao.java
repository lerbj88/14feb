package com.project.bdflujos.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Repository
@Transactional
public class ClienteDao extends JdbcDaoSupport {

    @Autowired
    public ClienteDao(DataSource dataSource1) {
        this.setDataSource(dataSource1);
    }


@Transactional
    public void insertclientes(String id, String name) {

        getJdbcTemplate().update("call system.INSERTCLIENTE (?, ?)", id, name);

    }


    @Transactional
    public void callInsertClientePrueba(String id, String name) {
        SimpleJdbcCall jdbcCall = new
                SimpleJdbcCall(getDataSource()).withProcedureName("insertcliente");

        SqlParameterSource in = new MapSqlParameterSource().addValue("p_id", id)
                .addValue("p_cliente", name);
        Map<String, Object> out = jdbcCall.execute(in);

        System.out.println(out.toString());
    }

}
